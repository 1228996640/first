interface Area{
    void getarea();
}
