
class Circle implements Area{
    public void getarea(){
        double r =2;
        double s = Math.PI * r * r;
        System.out.println("圆的面积是" + s);
    }
}
