class Triangle implements Area{
    public void getarea(){
        int s;
        int d=1;
        int h=2;
        s =d * h / 2;
        System.out.println("三角形面积是" + s);
    }
}
