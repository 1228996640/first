class Square implements Area{
    public void getarea(){
        int s;
        int d = 2;
        int h = 2;
        s = d * h;
        System.out.println("矩形的面积是" + s);
    }
}
