
public class Test{
    public static void main(String args []){
        Area a=new Triangle();
        a.getarea();
        Area b =new Square();
        b.getarea();
        Area c =new Circle();
        c.getarea();
    }
}
